package com.example.service

import com.example.model.EegBandState
import java.security.MessageDigest
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * STRUCTURAL SPECTRUM PROCESSOR -> |X| INTERCONNECT & GITHUB SNACK OUT-CONNECTOR
 *
 * Deterministic Kotlin port of `/public/assets/aistudio/structural_spectrum_processor_b1cbcace.py`
 * interconnected with the AXIOM |X| pipeline:
 *  1. 7-band FFT Structural Spectrum Processor (`DEFAULT_BANDS_HZ` & `INSTRUMENT_BANDS_HZ` / `ins_tru`)
 *  2. POT (Power-of-Two) FFT size snapping (`correctPotFftSize`) & POT-stabilized RMS (`potTaperGamma`)
 *  3. Asymmetric attack/release ballistic smoothing (`smoothStructureStep`, `attackMs=10`, `releaseMs=150`)
 *  4. Structural tension (`computeStructuralTension`) & Reinstake Interlock Guard (`evaluateReinstakeGuard`):
 *     Rule: "If not tension, not intent, burnout, or pipeline_logic_failure -> do not reinstake"
 *  5. |X| Tri-Layer Interconnect:
 *     - Osa A-X-00..09 Matrix Node Coupling
 *     - 3D GLSL Hex-Reflex / Fractal / Voronoi Uniform Modulation
 *     - SY4-EEG & ScreenFilterAnt Option C Frequency Filter Coupling
 *  6. GitHub Snack Out-Connector:
 *     - Airgap disconnects remote GitHub Snack / Gist / Webhook / PAT endpoints (`0.0 KB/S EGRESS`)
 *     - Produces a SHA-256 sealed, zero-secret sterile local bundle (`check:pass:true_only`)
 */
data class StructuralBandSpec(
    val index: Int,
    val lowHz: Float,
    val highHz: Float,
    val shortName: String,
    val fullLabel: String,
    val osaNodeCode: String,
    val osaNodeRole: String,
    val glslTargetLabel: String
)

data class StructuralBandActivation(
    val spec: StructuralBandSpec,
    val rawActivation: Float,
    val smoothedActivation: Float,
    val isSaturated: Boolean,
    val osaCoupledEntropy: Float,
    val osaOrdered: Boolean
)

data class StructuralSpectrumUiState(
    val insTruMode: Boolean = false,
    val InterconnectToXEnabled: Boolean = true,
    val interconnectStrength: Float = 0.85f,
    val sampleRateHz: Float = 48000.0f,
    val requestedFftSize: Int = 2048,
    val correctedPotFftSize: Int = 2048,
    val potThreshold: Float = 1e-12f,
    val potTaperGamma: Float = 1.0f,
    val attackMs: Float = 10.0f,
    val releaseMs: Float = 150.0f,
    val frameRateHz: Float = 60.0f,
    val burnoutCeiling: Float = 0.95f,
    val burnoutHoldFrames: Int = 8,
    val saturationStreak: Int = 0,
    val rawActivations: List<Float> = List(7) { 0f },
    val smoothedActivations: List<Float> = List(7) { 0f },
    val bandDetails: List<StructuralBandActivation> = emptyList(),
    val structuralTension: Float = 0.42f,
    val hasTension: Boolean = true,
    val hasIntent: Boolean = true,
    val burnoutTripped: Boolean = false,
    val pipelineLogicFailure: Boolean = false,
    val allowReinstake: Boolean = true,
    val reinstakeReason: String = "ok",
    // |X| Interconnect Derived Modulators
    val xHexScaleMod: Float = 0.0f,
    val xReflexDensityMod: Float = 0.0f,
    val xMagPressureMod: Float = 0.0f,
    val xAntiMagPulseMod: Float = 0.0f,
    val xOptionCHighFreqFilterGain: Float = 0.84f,
    val xCoherenceBoostPct: Int = 6,
    val spectrumSealSha256: String = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
)

data class GitHubSnackEndpointStatus(
    val id: String,
    val endpointPattern: String,
    val vectorCategory: String,
    val statusBadge: String = "OUTCONNECTED // SEVERED",
    val egressKbps: Float = 0.0f,
    val localReplacementPath: String
)

data class GitHubSnackOutconnectState(
    val isOutconnected: Boolean = true,
    val airgapLockActive: Boolean = true,
    val onlyLocalLogicFlag: Int = 1,
    val egressRateKbps: Float = 0.0f,
    val blockedSnackAttemptCount: Int = 4,
    val outconnectEpoch: Int = 1,
    val assertionToken: String = "GITHUB_SNACK:OUTCONNECTED // check:pass:true_only",
    val localSterileBundlePath: String = "file:///data/user/0/com.example/files/axiom_x_spectrum_snack_sterile.bundle",
    val sterileBundleSha256: String = "",
    val sterileBundlePreview: String = "",
    val severedEndpoints: List<GitHubSnackEndpointStatus> = emptyList(),
    val lastOutconnectSummary: String = "GitHub Snack Out-Connected • 4/4 Remote Gist/Webhook Vectors Severed • 0.0 KB/s Egress • Sterile Local Bundle Sealed"
)

object StructuralSpectrumProcessorEngine {

    val DEFAULT_BANDS_HZ: List<StructuralBandSpec> = listOf(
        StructuralBandSpec(
            index = 0,
            lowHz = 20.0f,
            highHz = 60.0f,
            shortName = "SUB",
            fullLabel = "Sub-Bass (20–60 Hz)",
            osaNodeCode = "A-X-00",
            osaNodeRole = "SHA-256 Root Anchor",
            glslTargetLabel = "u_hexScale Base"
        ),
        StructuralBandSpec(
            index = 1,
            lowHz = 60.0f,
            highHz = 250.0f,
            shortName = "BASS",
            fullLabel = "Bass (60–250 Hz)",
            osaNodeCode = "A-X-01",
            osaNodeRole = "Litterae Ingest",
            glslTargetLabel = "u_hexScale Lattice"
        ),
        StructuralBandSpec(
            index = 2,
            lowHz = 250.0f,
            highHz = 500.0f,
            shortName = "L-MID",
            fullLabel = "Low-Mid (250–500 Hz)",
            osaNodeCode = "A-X-02",
            osaNodeRole = "Hex Domain Core",
            glslTargetLabel = "u_magPressure Curl"
        ),
        StructuralBandSpec(
            index = 3,
            lowHz = 500.0f,
            highHz = 2000.0f,
            shortName = "MID",
            fullLabel = "Mid (500–2k Hz)",
            osaNodeCode = "A-X-03",
            osaNodeRole = "Sortis Integratio",
            glslTargetLabel = "u_reflexDensity Core"
        ),
        StructuralBandSpec(
            index = 4,
            lowHz = 2000.0f,
            highHz = 4000.0f,
            shortName = "U-MID",
            fullLabel = "Upper-Mid (2k–4k Hz)",
            osaNodeCode = "A-X-04",
            osaNodeRole = "Reflex Radial",
            glslTargetLabel = "u_reflexDensity Beam"
        ),
        StructuralBandSpec(
            index = 5,
            lowHz = 4000.0f,
            highHz = 8000.0f,
            shortName = "PRES",
            fullLabel = "Presence (4k–8k Hz)",
            osaNodeCode = "A-X-05",
            osaNodeRole = "SQLx SPECT Filter",
            glslTargetLabel = "u_antiMagPulse Gate"
        ),
        StructuralBandSpec(
            index = 6,
            lowHz = 8000.0f,
            highHz = 20000.0f,
            shortName = "BRIL",
            fullLabel = "Brilliance (8k–20k Hz)",
            osaNodeCode = "A-X-06",
            osaNodeRole = "Option-C HF Clamp",
            glslTargetLabel = "Option-C HF Denoise"
        )
    )

    val INSTRUMENT_BANDS_HZ: List<StructuralBandSpec> = listOf(
        StructuralBandSpec(
            index = 0,
            lowHz = 65.0f,
            highHz = 130.0f,
            shortName = "C2-C3",
            fullLabel = "C2–C3 Low Fundamental (65–130 Hz)",
            osaNodeCode = "A-X-00",
            osaNodeRole = "SHA-256 Fundamental",
            glslTargetLabel = "u_hexScale Root"
        ),
        StructuralBandSpec(
            index = 1,
            lowHz = 130.0f,
            highHz = 260.0f,
            shortName = "C3-C4",
            fullLabel = "C3–C4 Fundamental Body (130–260 Hz)",
            osaNodeCode = "A-X-01",
            osaNodeRole = "Litterae Body",
            glslTargetLabel = "u_hexScale Body"
        ),
        StructuralBandSpec(
            index = 2,
            lowHz = 260.0f,
            highHz = 520.0f,
            shortName = "C4-C5",
            fullLabel = "C4–C5 Warmth / Low-Harmonic (260–520 Hz)",
            osaNodeCode = "A-X-02",
            osaNodeRole = "Hex Warmth Domain",
            glslTargetLabel = "u_magPressure Warmth"
        ),
        StructuralBandSpec(
            index = 3,
            lowHz = 520.0f,
            highHz = 1040.0f,
            shortName = "C5-C6",
            fullLabel = "C5–C6 Center Harmonic (520–1040 Hz)",
            osaNodeCode = "A-X-03",
            osaNodeRole = "Sortis Harmonic Lock",
            glslTargetLabel = "u_reflexDensity Center"
        ),
        StructuralBandSpec(
            index = 4,
            lowHz = 1040.0f,
            highHz = 2080.0f,
            shortName = "ARTIC",
            fullLabel = "Upper Harmonic / Articulation (1.04k–2.08k Hz)",
            osaNodeCode = "A-X-04",
            osaNodeRole = "Reflex Articulation",
            glslTargetLabel = "u_reflexDensity Edge"
        ),
        StructuralBandSpec(
            index = 5,
            lowHz = 2080.0f,
            highHz = 4160.0f,
            shortName = "PLUCK",
            fullLabel = "Presence / Pluck / Bow Attack (2.08k–4.16k Hz)",
            osaNodeCode = "A-X-05",
            osaNodeRole = "SPECT Attack Gate",
            glslTargetLabel = "u_antiMagPulse Transient"
        ),
        StructuralBandSpec(
            index = 6,
            lowHz = 4160.0f,
            highHz = 12000.0f,
            shortName = "AIR",
            fullLabel = "Harmonic Brilliance / Overtone Air (4.16k–12k Hz)",
            osaNodeCode = "A-X-06",
            osaNodeRole = "Option-C Overtone Air",
            glslTargetLabel = "Option-C Air Shaper"
        )
    )

    fun activeBandsForMode(insTru: Boolean): List<StructuralBandSpec> =
        if (insTru) INSTRUMENT_BANDS_HZ else DEFAULT_BANDS_HZ

    /**
     * Snap `fftSize` to a valid Power-of-Two (POT: 2^k >= 2) consistent with `spectrumLen`.
     * Direct port of `correct_pot_fft_size` from `structural_spectrum_processor.py`.
     */
    fun correctPotFftSize(
        fftSize: Int,
        spectrumLen: Int,
        mode: String = "nearest"
    ): Int {
        val candidate = if (fftSize <= 0) {
            if (spectrumLen > 1) 2 * (spectrumLen - 1) else max(2, spectrumLen)
        } else {
            max(2, fftSize)
        }

        if (candidate >= 2 && (candidate and (candidate - 1)) == 0) {
            return candidate
        }

        val log2Val = ln(candidate.toDouble()) / ln(2.0)
        val expIndex = when (mode) {
            "floor" -> max(1, kotlin.math.floor(log2Val).toInt())
            "ceil" -> max(1, kotlin.math.ceil(log2Val).toInt())
            "nearest" -> max(1, log2Val.roundToInt())
            else -> max(1, log2Val.roundToInt())
        }
        return 1 shl expIndex
    }

    /**
     * Map raw FFT magnitudes into normalized 7-band structural activations in `[0.0, 1.0]`.
     * Direct port of `spectrum_to_structure` from `structural_spectrum_processor.py`.
     */
    fun spectrumToStructure(
        fftMagnitudes: FloatArray,
        sampleRateHz: Float,
        fftSize: Int = 0,
        insTru: Boolean = false,
        potThreshold: Float = 1e-12f,
        potTaperGamma: Float = 1.0f
    ): FloatArray {
        require(sampleRateHz > 0f) { "sampleRateHz must be > 0" }
        require(potThreshold >= 0f) { "potThreshold must be >= 0" }
        require(potTaperGamma > 0f) { "potTaperGamma must be > 0" }

        val bands = activeBandsForMode(insTru)
        val numBins = fftMagnitudes.size
        if (numBins == 0) {
            return FloatArray(bands.size) { 0.0f }
        }

        val resolvedFftSize = correctPotFftSize(fftSize, numBins, mode = "nearest")
        val binResolutionHz = sampleRateHz / resolvedFftSize.toFloat()
        val nyquistHz = sampleRateHz * 0.5f

        val rawEnergies = FloatArray(bands.size)
        for (i in bands.indices) {
            val spec = bands[i]
            val clampedLow = max(0.0f, min(spec.lowHz, nyquistHz))
            val clampedHigh = max(clampedLow, min(spec.highHz, nyquistHz))

            if (clampedHigh <= clampedLow) {
                rawEnergies[i] = 0.0f
                continue
            }

            val startBin = max(0, min(numBins - 1, (clampedLow / binResolutionHz).toInt()))
            val endBin = max(
                startBin + 1,
                min(numBins, kotlin.math.ceil((clampedHigh / binResolutionHz).toDouble()).toInt())
            )

            val sliceLen = endBin - startBin
            if (sliceLen <= 0) {
                rawEnergies[i] = 0.0f
                continue
            }

            // POT-stabilized RMS energy
            var powerSum = 0.0
            for (bin in startBin until endBin) {
                val mag = max(0.0f, fftMagnitudes[bin]).toDouble()
                powerSum += mag * mag
            }
            val meanPower = powerSum / sliceLen.toDouble()
            val rms = if (meanPower <= potThreshold.toDouble()) {
                0.0
            } else {
                sqrt(meanPower).pow(potTaperGamma.toDouble())
            }

            // Perceptual log compression: log10(1 + 9 * x)
            rawEnergies[i] = log10(1.0 + 9.0 * rms).toFloat()
        }

        val peak = rawEnergies.maxOrNull() ?: 0.0f
        if (peak <= 1e-12f) {
            return FloatArray(bands.size) { 0.0f }
        }

        return FloatArray(bands.size) { idx ->
            (rawEnergies[idx] / peak).coerceIn(0.0f, 1.0f)
        }
    }

    /**
     * Convert a time constant in milliseconds into a per-frame EMA coefficient.
     * Direct port of `time_constant_to_alpha`.
     */
    fun timeConstantToAlpha(timeConstantMs: Float, frameRateHz: Float): Float {
        require(frameRateHz > 0f) { "frameRateHz must be > 0" }
        if (timeConstantMs <= 0.0f) return 1.0f
        val dtSec = 1.0f / frameRateHz
        val tauSec = timeConstantMs * 1e-3f
        return (1.0f - exp(-dtSec / tauSec)).coerceIn(0.0f, 1.0f)
    }

    /**
     * Advance structural activations by one frame using asymmetric attack/release ballistics.
     * Direct port of `smooth_structure_step`.
     */
    fun smoothStructureStep(
        prevState: FloatArray,
        targetActivations: FloatArray,
        frameRateHz: Float,
        attackMs: Float = 10.0f,
        releaseMs: Float = 150.0f
    ): FloatArray {
        val alphaAttack = timeConstantToAlpha(attackMs, frameRateHz)
        val alphaRelease = timeConstantToAlpha(releaseMs, frameRateHz)
        val count = min(prevState.size, targetActivations.size)
        return FloatArray(count) { idx ->
            val prev = prevState[idx]
            val target = targetActivations[idx].coerceIn(0.0f, 1.0f)
            val alpha = if (target > prev) alphaAttack else alphaRelease
            (prev + alpha * (target - prev)).coerceIn(0.0f, 1.0f)
        }
    }

    /**
     * Compute aggregate structural tension scalar in `[0.0, 1.0]` and whether tension is present.
     * Direct port of `compute_structural_tension`.
     */
    fun computeStructuralTension(
        activations: FloatArray,
        minTension: Float = 1e-3f
    ): Pair<Float, Boolean> {
        if (activations.isEmpty()) return 0.0f to false
        var sum = 0.0f
        for (v in activations) {
            sum += v.coerceIn(0.0f, 1.0f)
        }
        val tensionScalar = (sum / activations.size.toFloat()).coerceIn(0.0f, 1.0f)
        return tensionScalar to (tensionScalar >= max(0.0f, minTension))
    }

    /**
     * Evaluate whether the structural pipeline is permitted to reinstake.
     * Rule: "If not tension, not intent, burnout, or pipeline_logic_failure -> do not reinstake"
     * Direct port of `evaluate_reinstake_guard`.
     */
    fun evaluateReinstakeGuard(
        tension: Boolean,
        intent: Boolean,
        burnout: Boolean,
        pipelineLogicFailure: Boolean = false
    ): Pair<Boolean, String> {
        if (pipelineLogicFailure) {
            return false to "pipeline_logic_failure_do_not_reinstake"
        }
        if (burnout) {
            return false to "burnout_do_not_reinstake"
        }
        if (!tension) {
            return false to "missing_tension_do_not_reinstake"
        }
        if (!intent) {
            return false to "missing_intent_do_not_reinstake"
        }
        return true to "ok"
    }

    /**
     * Synthesize a realistic 257-bin one-sided FFT magnitude spectrum (`fftSize = 512`)
     * driven by live SY4-EEG 5-band telemetry, |X| rotating frequency, and core tension string.
     */
    fun synthesizeLiveFftMagnitudes(
        simTime: Float,
        eegBands: EegBandState,
        rotatingFrequencyHz: Float,
        coreTensionString: Float,
        insTruMode: Boolean,
        sampleRateHz: Float = 48000.0f,
        fftSize: Int = 512
    ): FloatArray {
        val potFft = correctPotFftSize(fftSize, fftSize / 2 + 1, mode = "nearest")
        val numBins = potFft / 2 + 1
        val binHz = sampleRateHz / potFft.toFloat()
        val magnitudes = FloatArray(numBins)

        // Fundamental & overtone centers coupled to EEG bands + |X| rotating frequency
        val rotMod = (0.75f + rotatingFrequencyHz * 0.28f).coerceIn(0.6f, 2.4f)
        val tensionMod = (coreTensionString / 1.42f).coerceIn(0.4f, 1.8f)

        val bandCentersHz = if (insTruMode) {
            floatArrayOf(98.0f, 196.0f, 392.0f, 784.0f, 1568.0f, 3136.0f, 6272.0f)
        } else {
            floatArrayOf(42.0f, 140.0f, 370.0f, 1150.0f, 2900.0f, 5800.0f, 12500.0f)
        }

        val bandDrives = floatArrayOf(
            (eegBands.delta * 0.85f + 0.15f * abs(sin(simTime * 1.1f))) * tensionMod,
            (eegBands.theta * 0.88f + 0.12f * abs(cos(simTime * 1.4f))) * tensionMod,
            ((eegBands.theta + eegBands.alpha) * 0.48f + 0.14f * abs(sin(simTime * 1.8f))),
            (eegBands.alpha * 0.92f + 0.12f * abs(sin(simTime * 2.2f * rotMod))) * tensionMod,
            (eegBands.beta * 0.90f + 0.14f * abs(cos(simTime * 2.7f * rotMod))),
            ((eegBands.beta * 0.55f + eegBands.gamma * 0.45f) + 0.10f * abs(sin(simTime * 3.3f))),
            (eegBands.gamma * 0.78f + 0.08f * abs(cos(simTime * 4.1f)))
        )

        for (b in 0 until numBins) {
            val freq = b * binHz
            var amp = 0.002f
            for (k in bandCentersHz.indices) {
                val center = bandCentersHz[k]
                val bw = center * 0.36f
                val dist = (freq - center) / bw.coerceAtLeast(10.0f)
                val gaussian = exp(-0.5f * dist * dist)
                amp += bandDrives[k] * gaussian * 1.65f
            }
            magnitudes[b] = amp.coerceAtLeast(0.0f)
        }
        return magnitudes
    }

    /**
     * Advance the `StructuralSpectrumUiState` by one frame and compute all |X| pipeline couplings.
     */
    fun stepSpectrumProcessor(
        prevState: StructuralSpectrumUiState,
        fftMagnitudes: FloatArray,
        entropy: Float
    ): StructuralSpectrumUiState {
        val correctedPot = correctPotFftSize(
            fftSize = prevState.requestedFftSize,
            spectrumLen = fftMagnitudes.size,
            mode = "nearest"
        )

        var nextBurnout = prevState.burnoutTripped
        var nextLogicFail = prevState.pipelineLogicFailure
        var nextSatStreak = prevState.saturationStreak

        val rawTarget = try {
            spectrumToStructure(
                fftMagnitudes = fftMagnitudes,
                sampleRateHz = prevState.sampleRateHz,
                fftSize = correctedPot,
                insTru = prevState.insTruMode,
                potThreshold = prevState.potThreshold,
                potTaperGamma = prevState.potTaperGamma
            )
        } catch (_: Exception) {
            nextLogicFail = true
            FloatArray(7) { 0.0f }
        }

        val (tensionScalar, hasTension) = computeStructuralTension(rawTarget)

        val peakTarget = rawTarget.maxOrNull() ?: 0.0f
        if (peakTarget >= prevState.burnoutCeiling) {
            nextSatStreak += 1
            if (nextSatStreak >= prevState.burnoutHoldFrames) {
                nextBurnout = true
            }
        } else {
            nextSatStreak = max(0, nextSatStreak - 1)
        }

        val (allowReinstake, reason) = evaluateReinstakeGuard(
            tension = hasTension,
            intent = prevState.hasIntent,
            burnout = nextBurnout,
            pipelineLogicFailure = nextLogicFail
        )

        val prevSmoothedArr = if (prevState.smoothedActivations.size == 7) {
            prevState.smoothedActivations.toFloatArray()
        } else {
            FloatArray(7) { 0.0f }
        }

        val effectiveDrive = if (allowReinstake) {
            rawTarget
        } else {
            // Do not reinstake: feed zero drive so state safely decays via release ballistics
            FloatArray(7) { 0.0f }
        }

        val nextSmoothed = smoothStructureStep(
            prevState = prevSmoothedArr,
            targetActivations = effectiveDrive,
            frameRateHz = prevState.frameRateHz,
            attackMs = prevState.attackMs,
            releaseMs = prevState.releaseMs
        )

        val specs = activeBandsForMode(prevState.insTruMode)
        val details = specs.mapIndexed { idx, spec ->
            val rawVal = rawTarget.getOrElse(idx) { 0f }
            val smoothVal = nextSmoothed.getOrElse(idx) { 0f }
            val nodeEntropy = (entropy * (1.0f - smoothVal * 0.65f)).coerceIn(0.0f, 1.0f)
            val nodeOrdered = allowReinstake && nodeEntropy < 0.22f && smoothVal >= 0.08f
            StructuralBandActivation(
                spec = spec,
                rawActivation = rawVal,
                smoothedActivation = smoothVal,
                isSaturated = rawVal >= prevState.burnoutCeiling,
                osaCoupledEntropy = nodeEntropy,
                osaOrdered = nodeOrdered
            )
        }

        val gain = if (prevState.InterconnectToXEnabled && allowReinstake) {
            prevState.interconnectStrength.coerceIn(0.0f, 1.5f)
        } else {
            0.0f
        }

        // Map 7 bands to |X| GLSL & Option-C frequency filters:
        // Bands 0..1 (Sub/Bass or C2..C4) -> Hex Scale stability
        // Band 2 (Low-Mid / C4-C5) -> Magnetic Compressive Pressure
        // Bands 3..4 (Mid/Upper-Mid / C5..Artic) -> Reflex Radial Light Density
        // Band 5 (Presence / Pluck) -> Anti-Mag Blocking Boundary Pulse
        // Band 6 (Brilliance / Air) -> Option-C High-Frequency Noise Filter Attenuation
        val b0 = nextSmoothed[0]
        val b1 = nextSmoothed[1]
        val b2 = nextSmoothed[2]
        val b3 = nextSmoothed[3]
        val b4 = nextSmoothed[4]
        val b5 = nextSmoothed[5]
        val b6 = nextSmoothed[6]

        val hexMod = ((b0 * 0.45f + b1 * 0.55f) - 0.35f) * 0.42f * gain
        val reflexMod = ((b3 * 0.55f + b4 * 0.45f) - 0.30f) * 0.55f * gain
        val magMod = (b2 - 0.35f) * 0.48f * gain
        val antiMagMod = (b5 * 0.38f + tensionScalar * 0.22f) * gain
        // Option-C high-frequency filter: attenuates excessive Brilliance/HF noise while preserving harmonic air
        val optionCHfGain = (1.0f - (b6 * 0.38f * gain)).coerceIn(0.45f, 1.0f)
        val coherenceBoost = ((tensionScalar * 12.0f * gain).roundToInt()).coerceIn(0, 16)

        val sealPayload = buildString {
            append("MODE=").append(if (prevState.insTruMode) "INS_TRU" else "DEFAULT")
            append("|POT=").append(correctedPot)
            append("|TENSION=").append("%.4f".format(tensionScalar))
            append("|GUARD=").append(allowReinstake).append(":").append(reason)
            append("|BANDS=").append(nextSmoothed.joinToString(",") { "%.3f".format(it) })
        }
        val sha256 = sha256Hex(sealPayload)

        return prevState.copy(
            correctedPotFftSize = correctedPot,
            saturationStreak = nextSatStreak,
            rawActivations = rawTarget.toList(),
            smoothedActivations = nextSmoothed.toList(),
            bandDetails = details,
            structuralTension = tensionScalar,
            hasTension = hasTension,
            burnoutTripped = nextBurnout,
            pipelineLogicFailure = nextLogicFail,
            allowReinstake = allowReinstake,
            reinstakeReason = reason,
            xHexScaleMod = hexMod,
            xReflexDensityMod = reflexMod,
            xMagPressureMod = magMod,
            xAntiMagPulseMod = antiMagMod,
            xOptionCHighFreqFilterGain = optionCHfGain,
            xCoherenceBoostPct = coherenceBoost,
            spectrumSealSha256 = sha256
        )
    }

    /**
     * Guarded reinstake reset matching `StructuralSmoother.reinstake(tension, intent)`.
     */
    fun reinstakeProcessor(
        state: StructuralSpectrumUiState,
        tensionOverride: Boolean = true,
        intentOverride: Boolean = true
    ): StructuralSpectrumUiState {
        val clearedBurnout = false
        val clearedFailure = false
        val (allowed, reason) = evaluateReinstakeGuard(
            tension = tensionOverride,
            intent = intentOverride,
            burnout = clearedBurnout,
            pipelineLogicFailure = clearedFailure
        )
        return state.copy(
            hasIntent = intentOverride,
            hasTension = tensionOverride,
            burnoutTripped = clearedBurnout,
            pipelineLogicFailure = clearedFailure,
            saturationStreak = 0,
            allowReinstake = allowed,
            reinstakeReason = reason
        )
    }

    /**
     * Hard reset matching `StructuralSmoother.reset()`.
     */
    fun resetProcessor(state: StructuralSpectrumUiState): StructuralSpectrumUiState {
        val zeroList = List(7) { 0.0f }
        val specs = activeBandsForMode(state.insTruMode)
        val details = specs.map { spec ->
            StructuralBandActivation(
                spec = spec,
                rawActivation = 0.0f,
                smoothedActivation = 0.0f,
                isSaturated = false,
                osaCoupledEntropy = 0.0f,
                osaOrdered = true
            )
        }
        return state.copy(
            saturationStreak = 0,
            rawActivations = zeroList,
            smoothedActivations = zeroList,
            bandDetails = details,
            structuralTension = 0.0f,
            hasTension = true,
            hasIntent = true,
            burnoutTripped = false,
            pipelineLogicFailure = false,
            allowReinstake = true,
            reinstakeReason = "ok",
            xHexScaleMod = 0.0f,
            xReflexDensityMod = 0.0f,
            xMagPressureMod = 0.0f,
            xAntiMagPulseMod = 0.0f
        )
    }

    /**
     * Build the initial default state pre-populated with nominal 7-band activations.
     */
    fun buildInitialState(): StructuralSpectrumUiState {
        val base = StructuralSpectrumUiState()
        val initialFft = synthesizeLiveFftMagnitudes(
            simTime = 1.0f,
            eegBands = EegBandState(),
            rotatingFrequencyHz = 0.65f,
            coreTensionString = 1.42f,
            insTruMode = false
        )
        return stepSpectrumProcessor(base, initialFft, entropy = 0.04f)
    }

    fun sha256Hex(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }
}

/**
 * GITHUB SNACK OUT-CONNECTOR
 *
 * Enforces an airgap disconnect from all remote GitHub Snack / Gist / Webhook / Token relay
 * endpoints (`0.0 KB/S EGRESS`, `ONLY_LOCAL_LOGIC=1`) and generates a sterile, zero-secret
 * SHA-256 local bundle for the |X| pipeline.
 */
object GitHubSnackOutconnector {

    fun defaultSeveredEndpoints(): List<GitHubSnackEndpointStatus> = listOf(
        GitHubSnackEndpointStatus(
            id = "SNACK-GIST",
            endpointPattern = "https://gist.github.com/snack/* [OUTCONNECTED]",
            vectorCategory = "REMOTE GIST SNACK SYNC",
            statusBadge = "AIRGAP SEVERED // 0.0 KB/S",
            egressKbps = 0.0f,
            localReplacementPath = "file:///data/user/0/com.example/files/axiom_x_spectrum_snack_sterile.bundle"
        ),
        GitHubSnackEndpointStatus(
            id = "SNACK-API",
            endpointPattern = "https://api.github.com/repos/*/snack-relay [OUTCONNECTED]",
            vectorCategory = "GITHUB REST / WEBHOOK RELAY",
            statusBadge = "AIRGAP SEVERED // 0.0 KB/S",
            egressKbps = 0.0f,
            localReplacementPath = "sqlite:///data/user/0/com.example/databases/sy4_eeg_spect_local.db"
        ),
        GitHubSnackEndpointStatus(
            id = "SNACK-WSS",
            endpointPattern = "wss://snack.github.io/x-spectrum-telemetry [OUTCONNECTED]",
            vectorCategory = "LIVE TELEMETRY SOCKET",
            statusBadge = "AIRGAP SEVERED // 0.0 KB/S",
            egressKbps = 0.0f,
            localReplacementPath = "127.0.0.1:0 // Local In-Memory |X| Osa-A-X Bus"
        ),
        GitHubSnackEndpointStatus(
            id = "SNACK-PAT",
            endpointPattern = "Authorization: Bearer ghp_REDACTED / github_pat_REDACTED",
            vectorCategory = "CREDENTIAL / TOKEN HEADER",
            statusBadge = "ZERO-KEY PURGED // STERILE",
            egressKbps = 0.0f,
            localReplacementPath = "SHA-256 Epistula Seal (No Private Keys or Tokens)"
        )
    )

    fun buildSterileLocalBundle(
        spectrumState: StructuralSpectrumUiState,
        activeShaderKey: String,
        osaOrderedCount: Int,
        continuitySha256: String,
        outconnectEpoch: Int
    ): Pair<String, String> {
        val modeTag = if (spectrumState.insTruMode) "INSTRUMENT_BANDS_HZ (ins_tru=true)" else "DEFAULT_BANDS_HZ (ins_tru=false)"
        val bandLine = spectrumState.bandDetails.joinToString(" | ") { b ->
            "${b.spec.osaNodeCode}:${b.spec.shortName}=${"%.3f".format(b.smoothedActivation)}"
        }
        val bundleContent = buildString {
            appendLine("# AXIOM |X| STERILE LOCAL BUNDLE // GITHUB SNACK OUT-CONNECTED")
            appendLine("ONLY_LOCAL_LOGIC=1")
            appendLine("GITHUB_SNACK_STATUS=OUTCONNECTED_AIRGAP_LOCKED")
            appendLine("EGRESS_RATE_KBPS=0.0")
            appendLine("PRIVATE_KEYS_PRESENT=FALSE")
            appendLine("GITHUB_TOKENS_PRESENT=FALSE")
            appendLine("OUTCONNECT_EPOCH=$outconnectEpoch")
            appendLine("SPECTRUM_MODE=$modeTag")
            appendLine("POT_FFT_SIZE=${spectrumState.correctedPotFftSize}")
            appendLine("STRUCTURAL_TENSION=${"%.4f".format(spectrumState.structuralTension)}")
            appendLine("REINSTAKE_GUARD=${spectrumState.allowReinstake} (${spectrumState.reinstakeReason})")
            appendLine("X_OSA_BANDS=$bandLine")
            appendLine("X_GLSL_ARCH=$activeShaderKey")
            appendLine("X_OSA_ORDERED=$osaOrderedCount/10")
            appendLine("OPTION_C_HF_GAIN=${"%.3f".format(spectrumState.xOptionCHighFreqFilterGain)}")
            appendLine("CONTINUITY_PARENT_SHA256=${continuitySha256.take(32)}")
            appendLine("SPECTRUM_SEAL_SHA256=${spectrumState.spectrumSealSha256}")
        }.trim()

        val bundleSha = StructuralSpectrumProcessorEngine.sha256Hex(bundleContent)
        return bundleContent to bundleSha
    }

    fun buildInitialOutconnectState(
        spectrumState: StructuralSpectrumUiState = StructuralSpectrumProcessorEngine.buildInitialState(),
        activeShaderKey: String = "hex_reflex",
        osaOrderedCount: Int = 10,
        continuitySha256: String = "8f434346648f6b96df89dda901c5176b10a6d83961dd3c1ac88b59b2dc327aa4",
        epoch: Int = 1,
        blockedAttempts: Int = 4
    ): GitHubSnackOutconnectState {
        val (bundle, sha) = buildSterileLocalBundle(
            spectrumState = spectrumState,
            activeShaderKey = activeShaderKey,
            osaOrderedCount = osaOrderedCount,
            continuitySha256 = continuitySha256,
            outconnectEpoch = epoch
        )
        return GitHubSnackOutconnectState(
            isOutconnected = true,
            airgapLockActive = true,
            onlyLocalLogicFlag = 1,
            egressRateKbps = 0.0f,
            blockedSnackAttemptCount = blockedAttempts,
            outconnectEpoch = epoch,
            assertionToken = "GITHUB_SNACK:OUTCONNECTED // check:pass:true_only",
            sterileBundleSha256 = sha,
            sterileBundlePreview = bundle,
            severedEndpoints = defaultSeveredEndpoints(),
            lastOutconnectSummary = "GitHub Snack Out-Connected (#$epoch) • 4/4 Remote Endpoints Severed • 0.0 KB/s Egress • Sterile SHA-256 ${sha.take(12)}..."
        )
    }
}
