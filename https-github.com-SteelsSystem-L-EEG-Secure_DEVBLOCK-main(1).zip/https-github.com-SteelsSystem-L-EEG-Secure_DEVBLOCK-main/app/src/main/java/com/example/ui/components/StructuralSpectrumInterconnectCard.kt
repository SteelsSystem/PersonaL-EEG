package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.GitHubSnackOutconnectState
import com.example.service.StructuralSpectrumUiState
import com.example.ui.theme.AntiMagCobaltCyan
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.SlateBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StructuralSpectrumInterconnectCard(
    spectrumState: StructuralSpectrumUiState,
    snackState: GitHubSnackOutconnectState,
    onToggleInsTruMode: () -> Unit,
    onToggleIntent: () -> Unit,
    onUpdatePotGamma: (Float) -> Unit,
    onUpdateInterconnectGain: (Float) -> Unit,
    onTriggerBurnoutTest: () -> Unit,
    onReinstakeSpectrum: () -> Unit,
    onResetSpectrum: () -> Unit,
    onOutconnectGitHubSnack: () -> Unit,
    onSimulateSnackLeakBlocked: () -> Unit,
    onCopyToast: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val guardColor = when {
        spectrumState.burnoutTripped || spectrumState.pipelineLogicFailure -> NeonPink
        !spectrumState.allowReinstake -> NeonAmber
        spectrumState.insTruMode -> NeonPurple
        else -> NeonGreen
    }

    HudCard(
        borderColor = guardColor,
        modifier = modifier.testTag("card_structural_spectrum_interconnect")
    ) {
        // 1. Header Banner
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(9.dp)
                            .clip(CircleShape)
                            .background(guardColor)
                    )
                    Text(
                        text = "|X| STRUCTURAL SPECTRUM INTERCONNECT",
                        style = MaterialTheme.typography.titleSmall,
                        color = guardColor,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = if (spectrumState.insTruMode) {
                        "7-Band INSTRUMENT_BANDS_HZ [ins_tru=true • C2–C6 Harmonics] ➔ Osa A-X + GLSL + EEG"
                    } else {
                        "7-Band DEFAULT_BANDS_HZ [20Hz–20kHz POT FFT] ➔ Osa A-X + GLSL + Option-C Filter"
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                    fontSize = 8.5.sp
                )
            }

            StatusBadge(
                text = if (spectrumState.allowReinstake) {
                    "REINSTAKE: OK"
                } else {
                    "GUARD: ${spectrumState.reinstakeReason.uppercase().take(18)}"
                },
                color = guardColor
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 2. Key Telemetry Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            MiniStatBox(
                title = "POT FFT SIZE",
                value = "${spectrumState.correctedPotFftSize} BINS",
                valueColor = NeonCyan,
                modifier = Modifier.weight(1f)
            )
            MiniStatBox(
                title = "TENSION",
                value = "${"%.2f".format(spectrumState.structuralTension)} ${if (spectrumState.hasTension) "✓" else "LOW"}",
                valueColor = if (spectrumState.hasTension) NeonGreen else NeonAmber,
                modifier = Modifier.weight(1f)
            )
            MiniStatBox(
                title = "OPTION-C HF",
                value = "${(spectrumState.xOptionCHighFreqFilterGain * 100).toInt()}% CLEAN",
                valueColor = AntiMagCobaltCyan,
                modifier = Modifier.weight(1f)
            )
            MiniStatBox(
                title = "|X| COHERENCE",
                value = "+${spectrumState.xCoherenceBoostPct}% LOCK",
                valueColor = NeonPurple,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 3. Live 7-Band Structural Spectrum Canvas + Burnout Ceiling (0.95)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(124.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(ObsidianBg.copy(alpha = 0.92f))
                .border(1.dp, SlateBorder, RoundedCornerShape(8.dp))
                .padding(8.dp)
                .testTag("canvas_structural_spectrum_7band")
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val bandCount = 7
                val slotWidth = w / bandCount.toFloat()
                val barWidth = slotWidth * 0.56f

                // Burnout ceiling threshold line at 0.95
                val ceilingY = h * (1.0f - spectrumState.burnoutCeiling.coerceIn(0.5f, 1.0f))
                drawLine(
                    color = NeonPink.copy(alpha = 0.65f),
                    start = Offset(0f, ceilingY),
                    end = Offset(w, ceilingY),
                    strokeWidth = 1.2.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f)
                )

                // Structural tension mean line
                val tensionY = h * (1.0f - spectrumState.structuralTension.coerceIn(0f, 1f))
                drawLine(
                    color = NeonGreen.copy(alpha = 0.45f),
                    start = Offset(0f, tensionY),
                    end = Offset(w, tensionY),
                    strokeWidth = 1.dp.toPx()
                )

                for (i in 0 until bandCount) {
                    val rawVal = spectrumState.rawActivations.getOrElse(i) { 0f }.coerceIn(0f, 1f)
                    val smoothVal = spectrumState.smoothedActivations.getOrElse(i) { 0f }.coerceIn(0f, 1f)
                    val centerX = slotWidth * (i + 0.5f)
                    val leftX = centerX - barWidth * 0.5f

                    val barColor = when {
                        rawVal >= spectrumState.burnoutCeiling -> NeonPink
                        spectrumState.insTruMode -> when (i % 3) {
                            0 -> NeonPurple
                            1 -> NeonCyan
                            else -> NeonGreen
                        }
                        else -> when (i) {
                            0, 1 -> NeonCyan
                            2, 3 -> NeonGreen
                            4, 5 -> AntiMagCobaltCyan
                            else -> NeonAmber
                        }
                    }

                    // Background track
                    drawRoundRect(
                        color = SlateBorder.copy(alpha = 0.25f),
                        topLeft = Offset(leftX, 0f),
                        size = Size(barWidth, h),
                        cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                    )

                    // Smoothed activation bar (attack=10ms, release=150ms)
                    val barH = (smoothVal * h).coerceAtLeast(3.dp.toPx())
                    drawRoundRect(
                        color = barColor.copy(alpha = 0.82f),
                        topLeft = Offset(leftX, h - barH),
                        size = Size(barWidth, barH),
                        cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                    )

                    // Raw instantaneous peak cap line
                    val rawY = h - (rawVal * h)
                    drawLine(
                        color = Color.White.copy(alpha = 0.9f),
                        start = Offset(leftX, rawY),
                        end = Offset(leftX + barWidth, rawY),
                        strokeWidth = 2.dp.toPx()
                    )
                }
            }

            Row(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = if (spectrumState.insTruMode) "MODE: INSTRUMENT [ins_tru=true • C2–C6]" else "MODE: DEFAULT [20Hz–20kHz]",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (spectrumState.insTruMode) NeonPurple else NeonCyan,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "CEILING ${"%.2f".format(spectrumState.burnoutCeiling)} • ATT 10ms / REL 150ms",
                    style = MaterialTheme.typography.labelSmall,
                    color = NeonPink,
                    fontSize = 7.5.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // 4. 7-Band Osa A-X-00..06 Node Mapping Pills
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            spectrumState.bandDetails.forEach { band ->
                val pillColor = when {
                    band.isSaturated -> NeonPink
                    band.osaOrdered -> NeonGreen
                    else -> NeonCyan
                }
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(ObsidianBg)
                        .border(1.dp, pillColor.copy(alpha = 0.55f), RoundedCornerShape(6.dp))
                        .padding(vertical = 4.dp, horizontal = 2.dp)
                ) {
                    Text(
                        text = band.spec.shortName,
                        style = MaterialTheme.typography.labelSmall,
                        color = pillColor,
                        fontSize = 7.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${(band.smoothedActivation * 100).toInt()}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextPrimary,
                        fontSize = 7.5.sp
                    )
                    Text(
                        text = band.spec.osaNodeCode,
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted,
                        fontSize = 6.5.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 5. |X| GLSL & Reinstake Guard Rule Readout Box
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(ObsidianBg)
                .border(1.dp, SlateBorder, RoundedCornerShape(6.dp))
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = "GUARD RULE: if (!tension || !intent || burnout || pipeline_logic_failure) -> do_not_reinstake (status: ${spectrumState.reinstakeReason})",
                style = MaterialTheme.typography.labelSmall,
                color = guardColor,
                fontSize = 8.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "|X| DELTAS: Δhex=${"%+.2f".format(spectrumState.xHexScaleMod)} • Δreflex=${"%+.2f".format(spectrumState.xReflexDensityMod)} • Δmag=${"%+.2f".format(spectrumState.xMagPressureMod)} • ΔantiMag=${"%+.2f".format(spectrumState.xAntiMagPulseMod)}",
                style = MaterialTheme.typography.labelSmall,
                color = NeonCyan,
                fontSize = 8.sp
            )
            Text(
                text = "SPECTRUM SHA-256: ${spectrumState.spectrumSealSha256.take(28)}...",
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted,
                fontSize = 7.5.sp
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 6. Live Mode & Intent Toggles
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Button(
                onClick = onToggleInsTruMode,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (spectrumState.insTruMode) NeonPurple.copy(alpha = 0.25f) else NeonCyan.copy(alpha = 0.20f),
                    contentColor = if (spectrumState.insTruMode) NeonPurple else NeonCyan
                ),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .weight(1f)
                    .minimumInteractiveComponentSize()
                    .border(
                        1.dp,
                        if (spectrumState.insTruMode) NeonPurple else NeonCyan,
                        RoundedCornerShape(6.dp)
                    )
                    .testTag("btn_toggle_ins_tru_spectrum")
            ) {
                Text(
                    text = if (spectrumState.insTruMode) "♪ MODE: INSTRUMENT [ins_tru]" else "⇄ MODE: DEFAULT BANDS",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 8.5.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }

            Button(
                onClick = onToggleIntent,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (spectrumState.hasIntent) NeonGreen.copy(alpha = 0.24f) else NeonAmber.copy(alpha = 0.22f),
                    contentColor = if (spectrumState.hasIntent) NeonGreen else NeonAmber
                ),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .weight(1f)
                    .minimumInteractiveComponentSize()
                    .border(
                        1.dp,
                        if (spectrumState.hasIntent) NeonGreen else NeonAmber,
                        RoundedCornerShape(6.dp)
                    )
                    .testTag("btn_toggle_spectrum_intent")
            ) {
                Text(
                    text = if (spectrumState.hasIntent) "✓ INTENT: CONFIRMED" else "⚠ INTENT: WITHHELD",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 8.5.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // 7. POT Taper Gamma & |X| Interconnect Gain Sliders
        LabeledSliderRow(
            label = "POT RMS Taper Gamma (pot_taper_gamma)",
            valueText = "${"%.2f".format(spectrumState.potTaperGamma)} γ",
            valueColor = NeonCyan,
            value = spectrumState.potTaperGamma,
            valueRange = 0.50f..2.00f,
            onValueChange = onUpdatePotGamma,
            testTag = "slider_spectrum_pot_gamma"
        )

        LabeledSliderRow(
            label = "|X| Pipeline Interconnect Coupling Gain",
            valueText = "${(spectrumState.interconnectStrength * 100).toInt()}%",
            valueColor = NeonGreen,
            value = spectrumState.interconnectStrength,
            valueRange = 0.0f..1.50f,
            onValueChange = onUpdateInterconnectGain,
            testTag = "slider_spectrum_interconnect_gain"
        )

        Spacer(modifier = Modifier.height(6.dp))

        // 8. Reinstake Guard Actions (Simulate Burnout, Guarded Reinstake, Hard Reset)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Button(
                onClick = onTriggerBurnoutTest,
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonPink.copy(alpha = 0.22f),
                    contentColor = NeonPink
                ),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .weight(1f)
                    .minimumInteractiveComponentSize()
                    .border(1.dp, NeonPink, RoundedCornerShape(6.dp))
                    .testTag("btn_spectrum_simulate_burnout")
            ) {
                Text(
                    text = "⚡ Burnout Test",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Button(
                onClick = onReinstakeSpectrum,
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonGreen.copy(alpha = 0.24f),
                    contentColor = NeonGreen
                ),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .weight(1f)
                    .minimumInteractiveComponentSize()
                    .border(1.dp, NeonGreen, RoundedCornerShape(6.dp))
                    .testTag("btn_spectrum_reinstake")
            ) {
                Text(
                    text = "⟳ Reinstake |X|",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Button(
                onClick = onResetSpectrum,
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonCyan.copy(alpha = 0.20f),
                    contentColor = NeonCyan
                ),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .weight(1f)
                    .minimumInteractiveComponentSize()
                    .border(1.dp, NeonCyan, RoundedCornerShape(6.dp))
                    .testTag("btn_spectrum_reset")
            ) {
                Text(
                    text = "Reset Smoother",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 9. Embedded GitHub Snack Out-Connector Section
        GitHubSnackOutconnectSection(
            snackState = snackState,
            onOutconnectGitHubSnack = onOutconnectGitHubSnack,
            onSimulateSnackLeakBlocked = onSimulateSnackLeakBlocked,
            onCopyToast = onCopyToast
        )
    }
}

@Composable
fun GitHubSnackOutconnectSection(
    snackState: GitHubSnackOutconnectState,
    onOutconnectGitHubSnack: () -> Unit,
    onSimulateSnackLeakBlocked: () -> Unit,
    onCopyToast: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val clipboard = LocalClipboardManager.current
    val statusColor = if (snackState.isOutconnected && snackState.airgapLockActive) NeonGreen else NeonAmber

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(ObsidianBg.copy(alpha = 0.90f))
            .border(1.dp, statusColor.copy(alpha = 0.75f), RoundedCornerShape(8.dp))
            .padding(10.dp)
            .testTag("section_github_snack_outconnect")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "GITHUB SNACK OUT-CONNECTOR // AIRGAP LOCK",
                    style = MaterialTheme.typography.titleSmall,
                    color = statusColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
                Text(
                    text = "Remote GitHub Snack / Gist / PAT Egress Severed • Sterile Local Bundle Sealed",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                    fontSize = 8.sp
                )
            }
            StatusBadge(
                text = "OUTCONNECTED // 0.0 KB/S",
                color = statusColor
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            MiniStatBox(
                title = "SNACK EGRESS",
                value = "${"%.1f".format(snackState.egressRateKbps)} KB/S",
                valueColor = NeonGreen,
                modifier = Modifier.weight(1f)
            )
            MiniStatBox(
                title = "SEVERED HOOKS",
                value = "${snackState.severedEndpoints.size}/4 LOCKED",
                valueColor = NeonCyan,
                modifier = Modifier.weight(1f)
            )
            MiniStatBox(
                title = "BLOCKED LEAKS",
                value = "#${snackState.blockedSnackAttemptCount}",
                valueColor = NeonAmber,
                modifier = Modifier.weight(1f)
            )
            MiniStatBox(
                title = "STERILE SEAL",
                value = "EPOCH #${snackState.outconnectEpoch}",
                valueColor = NeonPurple,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Severed GitHub Snack Endpoints List
        Column(
            verticalArrangement = Arrangement.spacedBy(4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            snackState.severedEndpoints.forEach { ep ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(5.dp))
                        .background(ObsidianBg)
                        .border(1.dp, SlateBorder, RoundedCornerShape(5.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${ep.id} • ${ep.endpointPattern}",
                            style = MaterialTheme.typography.labelSmall,
                            color = NeonCyan,
                            fontSize = 7.8.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Local Route: ${ep.localReplacementPath}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted,
                            fontSize = 7.2.sp
                        )
                    }
                    Text(
                        text = ep.statusBadge,
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonGreen,
                        fontSize = 7.2.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = snackState.lastOutconnectSummary,
            style = MaterialTheme.typography.labelSmall,
            color = NeonGreen,
            fontSize = 8.sp
        )

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Button(
                onClick = {
                    onOutconnectGitHubSnack()
                    clipboard.setText(AnnotatedString(snackState.sterileBundlePreview))
                    onCopyToast("GitHub Snack Out-Connected & Sterile Local Bundle Copied (SHA-256: ${snackState.sterileBundleSha256.take(10)}...)")
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonGreen.copy(alpha = 0.24f),
                    contentColor = NeonGreen
                ),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .weight(1.35f)
                    .minimumInteractiveComponentSize()
                    .border(1.dp, NeonGreen, RoundedCornerShape(6.dp))
                    .testTag("btn_outconnect_github_snack")
            ) {
                Text(
                    text = "✓ OUT-CONNECT GITHUB SNACK & SEAL STERILE BUNDLE",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }

            Button(
                onClick = onSimulateSnackLeakBlocked,
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonAmber.copy(alpha = 0.22f),
                    contentColor = NeonAmber
                ),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .weight(1f)
                    .minimumInteractiveComponentSize()
                    .border(1.dp, NeonAmber, RoundedCornerShape(6.dp))
                    .testTag("btn_test_github_snack_block")
            ) {
                Text(
                    text = "🛡 Test Snack Egress Block",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}
