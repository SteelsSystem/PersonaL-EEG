package com.example

import com.example.service.GitHubSnackOutconnector
import com.example.service.StructuralSpectrumProcessorEngine
import com.example.service.StructuralSpectrumUiState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class StructuralSpectrumProcessorTest {

    @Test
    fun correctPotFftSize_snapsToPowerOfTwo() {
        assertEquals(2048, StructuralSpectrumProcessorEngine.correctPotFftSize(0, 1025, "nearest"))
        assertEquals(1024, StructuralSpectrumProcessorEngine.correctPotFftSize(1000, 513, "nearest"))
        assertEquals(512, StructuralSpectrumProcessorEngine.correctPotFftSize(900, 451, "floor"))
        assertEquals(1024, StructuralSpectrumProcessorEngine.correctPotFftSize(520, 261, "ceil"))
    }

    @Test
    fun spectrumToStructure_normalizesDefaultAndInsTruModes() {
        val sampleRate = 48000f
        val fftSize = 2048
        val numBins = fftSize / 2 + 1
        val magnitudes = FloatArray(numBins) { idx ->
            when {
                idx in 18..42 -> 1.5f // Mid/Harmonic peak
                idx in 3..10 -> 0.6f
                else -> 0.05f
            }
        }

        val defaultBands = StructuralSpectrumProcessorEngine.spectrumToStructure(
            fftMagnitudes = magnitudes,
            sampleRateHz = sampleRate,
            fftSize = fftSize,
            insTru = false
        )
        assertEquals(7, defaultBands.size)
        assertEquals(1.0f, defaultBands.maxOrNull() ?: 0f, 1e-4f)
        assertTrue(defaultBands.all { it in 0.0f..1.0f })

        val insTruBands = StructuralSpectrumProcessorEngine.spectrumToStructure(
            fftMagnitudes = magnitudes,
            sampleRateHz = sampleRate,
            fftSize = fftSize,
            insTru = true
        )
        assertEquals(7, insTruBands.size)
        assertEquals(1.0f, insTruBands.maxOrNull() ?: 0f, 1e-4f)
        assertTrue(insTruBands.all { it in 0.0f..1.0f })
    }

    @Test
    fun evaluateReinstakeGuard_enforcesAllFourBlockConditions() {
        val (allowFail, reasonFail) = StructuralSpectrumProcessorEngine.evaluateReinstakeGuard(
            tension = true,
            intent = true,
            burnout = false,
            pipelineLogicFailure = true
        )
        assertFalse(allowFail)
        assertEquals("pipeline_logic_failure_do_not_reinstake", reasonFail)

        val (allowBurnout, reasonBurnout) = StructuralSpectrumProcessorEngine.evaluateReinstakeGuard(
            tension = true,
            intent = true,
            burnout = true,
            pipelineLogicFailure = false
        )
        assertFalse(allowBurnout)
        assertEquals("burnout_do_not_reinstake", reasonBurnout)

        val (allowNoTension, reasonNoTension) = StructuralSpectrumProcessorEngine.evaluateReinstakeGuard(
            tension = false,
            intent = true,
            burnout = false,
            pipelineLogicFailure = false
        )
        assertFalse(allowNoTension)
        assertEquals("missing_tension_do_not_reinstake", reasonNoTension)

        val (allowNoIntent, reasonNoIntent) = StructuralSpectrumProcessorEngine.evaluateReinstakeGuard(
            tension = true,
            intent = false,
            burnout = false,
            pipelineLogicFailure = false
        )
        assertFalse(allowNoIntent)
        assertEquals("missing_intent_do_not_reinstake", reasonNoIntent)

        val (allowOk, reasonOk) = StructuralSpectrumProcessorEngine.evaluateReinstakeGuard(
            tension = true,
            intent = true,
            burnout = false,
            pipelineLogicFailure = false
        )
        assertTrue(allowOk)
        assertEquals("ok", reasonOk)
    }

    @Test
    fun stepSpectrumProcessor_latchesBurnoutAndRecoversOnGuardedReinstake() {
        var state = StructuralSpectrumUiState(
            burnoutCeiling = 0.95f,
            burnoutHoldFrames = 3
        )
        val uniformSaturatedFft = FloatArray(257) { 10.0f }

        repeat(3) {
            state = StructuralSpectrumProcessorEngine.stepSpectrumProcessor(
                prevState = state,
                fftMagnitudes = uniformSaturatedFft,
                entropy = 0.05f
            )
        }
        assertTrue(state.burnoutTripped)
        assertFalse(state.allowReinstake)
        assertEquals("burnout_do_not_reinstake", state.reinstakeReason)

        val reinstated = StructuralSpectrumProcessorEngine.reinstakeProcessor(
            state = state,
            tensionOverride = true,
            intentOverride = true
        )
        assertFalse(reinstated.burnoutTripped)
        assertTrue(reinstated.allowReinstake)
        assertEquals("ok", reinstated.reinstakeReason)
    }

    @Test
    fun githubSnackOutconnector_seversRemoteEndpointsAndSealsSterileBundle() {
        val state = GitHubSnackOutconnector.buildInitialOutconnectState()
        assertTrue(state.isOutconnected)
        assertTrue(state.airgapLockActive)
        assertEquals(0.0f, state.egressRateKbps, 1e-6f)
        assertEquals(4, state.severedEndpoints.size)
        assertEquals(64, state.sterileBundleSha256.length)
        assertTrue(state.sterileBundlePreview.contains("ONLY_LOCAL_LOGIC=1"))
        assertTrue(state.sterileBundlePreview.contains("GITHUB_SNACK_STATUS=OUTCONNECTED_AIRGAP_LOCKED"))
        assertTrue(state.sterileBundlePreview.contains("PRIVATE_KEYS_PRESENT=FALSE"))
    }
}
