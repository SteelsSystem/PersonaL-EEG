import numpy as np

# Deterministic structural frequency bands in Hz (Sub-bass to Brilliance)
DEFAULT_BANDS_HZ = (
    (20.0, 60.0),
    (60.0, 250.0),
    (250.0, 500.0),
    (500.0, 2000.0),
    (2000.0, 4000.0),
    (4000.0, 8000.0),
    (8000.0, 20000.0),
)

# Instrument-focused ("ins_tru") harmonic bands in Hz (Fundamental to Air)
INSTRUMENT_BANDS_HZ = (
    (65.0, 130.0),    # Low Fundamental (C2 - C3)
    (130.0, 260.0),   # Warmth / Body (C3 - C4)
    (260.0, 520.0),   # Primary Formant (C4 - C5)
    (520.0, 1040.0),  # Center Harmonics (C5 - C6)
    (1040.0, 2080.0), # Articulation / Projection
    (2080.0, 4160.0), # Presence / Bite
    (4160.0, 12000.0) # Harmonic Brilliance / Overtones
)


def correct_pot_fft_size(fft_size, spectrum_len=None, mode="nearest"):
    """
    Ensure deterministic Power-of-Two (POT) FFT size alignment.

    Parameters:
        fft_size: Nominal FFT window size (must be > 0).
        spectrum_len: Optional length of input spectrum array to cross-check
                      one-sided RFFT bin counts ((N // 2) + 1).
        mode: 'nearest', 'next', or 'infer' (infer from spectrum_len if POT).

    Returns:
        Corrected integer Power-of-Two fft_size >= 2.
    """
    if fft_size <= 0:
        raise ValueError("fft_size must be positive.")

    n = int(fft_size)

    # Check if spectrum_len implies a standard one-sided RFFT of a POT size
    if mode == "infer" and spectrum_len is not None and spectrum_len > 1:
        inferred_n = 2 * (int(spectrum_len) - 1)
        if inferred_n >= 2 and (inferred_n & (inferred_n - 1)) == 0:
            return inferred_n

    # Already a power of two
    if n >= 2 and (n & (n - 1)) == 0:
        return n

    if n < 2:
        return 2

    log2_n = np.log2(float(n))
    if mode == "next":
        exp = int(np.ceil(log2_n))
    else:
        exp = int(np.round(log2_n))

    return max(2, 1 << exp)


def spectrum_to_structure(
    spectrum,
    sample_rate,
    fft_size,
    bands_hz=DEFAULT_BANDS_HZ,
    enforce_pot_fft=True,
    pot_threshold=1e-6,
    pot_taper_gamma=1.0,
    ins_tru=False,
):
    """
    Convert measured FFT magnitude data into a normalized structural activation vector.

    Input:
        spectrum: measured FFT magnitude data
        sample_rate: sampling frequency in Hz (must be > 0)
        fft_size: total FFT window size (must be > 0)
        bands_hz: tuple of (low_hz, high_hz) deterministic band boundaries
        enforce_pot_fft: if True, snaps/validates fft_size to a Power-of-Two (POT)
        pot_threshold: Peak-Over-Threshold (POT) reference floor (>= 0.0) so
                       near-zero noise does not normalize up to 1.0
        pot_taper_gamma: perceptual/potentiometer taper exponent (> 0.0, 1.0 = linear)
        ins_tru: if True and bands_hz is DEFAULT_BANDS_HZ, uses INSTRUMENT_BANDS_HZ

    Output:
        normalized structural activation vector (numpy.ndarray of float64)

    Constraints:
        finite values
        range [0.0, 1.0]
        deterministic band boundaries
        explicit handling of empty bands
    """
    if sample_rate <= 0 or fft_size <= 0:
        raise ValueError("sample_rate and fft_size must be positive.")

    active_bands = (
        INSTRUMENT_BANDS_HZ
        if (ins_tru and bands_hz is DEFAULT_BANDS_HZ)
        else bands_hz
    )

    # 1. Enforce finite, non-negative magnitude values
    mag = np.asarray(spectrum, dtype=np.float64).ravel()
    mag = np.nan_to_num(mag, nan=0.0, posinf=0.0, neginf=0.0)
    mag = np.maximum(mag, 0.0)

    # 2. Power-of-Two (POT) FFT size correction
    effective_fft_size = (
        correct_pot_fft_size(fft_size, spectrum_len=mag.size, mode="nearest")
        if enforce_pot_fft
        else int(fft_size)
    )

    # Restrict to valid one-sided spectrum bins [0, effective_fft_size // 2]
    max_bins = (effective_fft_size // 2) + 1
    mag = mag[:max_bins]
    num_bins = mag.size

    # Deterministic bin frequencies: f[k] = k * sample_rate / effective_fft_size
    bin_freqs = np.arange(num_bins, dtype=np.float64) * (
        float(sample_rate) / float(effective_fft_size)
    )

    activations = np.zeros(len(active_bands), dtype=np.float64)

    # 3. Aggregate energy per deterministic band with explicit empty-band handling
    for i, (f_low, f_high) in enumerate(active_bands):
        if num_bins == 0 or f_high <= f_low:
            activations[i] = 0.0
            continue

        # Deterministic half-open interval [f_low, f_high)
        mask = (bin_freqs >= f_low) & (bin_freqs < f_high)

        if not np.any(mask):
            # Explicit handling when no FFT bin falls inside the band
            activations[i] = 0.0
        else:
            # Root-mean-square (RMS) magnitude across bins in the band
            band_slice = mag[mask]
            activations[i] = float(np.sqrt(np.mean(np.square(band_slice))))

    # 4. Peak-Over-Threshold (POT) stabilized normalization to [0.0, 1.0]
    floor = float(max(0.0, np.nan_to_num(pot_threshold, nan=0.0)))
    peak = float(np.max(activations)) if activations.size > 0 else 0.0
    denom = max(peak, floor)

    if denom > 0.0 and np.isfinite(denom):
        activations = activations / denom
    else:
        activations.fill(0.0)

    # 5. Optional potentiometer / perceptual taper curve while preserving [0.0, 1.0]
    gamma = float(np.nan_to_num(pot_taper_gamma, nan=1.0, posinf=1.0, neginf=1.0))
    if gamma > 0.0 and gamma != 1.0:
        activations = np.power(np.clip(activations, 0.0, 1.0), gamma)

    # Final safety clip and finite guarantee
    activations = np.nan_to_num(activations, nan=0.0, posinf=1.0, neginf=0.0)
    return np.clip(activations, 0.0, 1.0)


def time_constant_to_alpha(tau_ms, sample_rate, hop_size):
    """
    Convert a time constant in milliseconds to a discrete EMA coefficient in [0.0, 1.0].
    """
    if sample_rate <= 0 or hop_size <= 0:
        raise ValueError("sample_rate and hop_size must be positive.")

    if not np.isfinite(tau_ms) or tau_ms <= 0.0:
        return 1.0

    dt_sec = float(hop_size) / float(sample_rate)
    tau_sec = float(tau_ms) * 1e-3
    alpha = 1.0 - np.exp(-dt_sec / tau_sec)
    return float(np.clip(alpha, 0.0, 1.0))


def smooth_structure_step(current_vec, prev_vec, alpha_attack, alpha_release):
    """
    Stateless per-frame asymmetric EMA step (attack/release ballistics).
    """
    curr = np.asarray(current_vec, dtype=np.float64).ravel()
    curr = np.nan_to_num(curr, nan=0.0, posinf=1.0, neginf=0.0)
    curr = np.clip(curr, 0.0, 1.0)

    if prev_vec is None:
        return curr.copy()

    prev = np.asarray(prev_vec, dtype=np.float64).ravel()
    if prev.shape != curr.shape:
        raise ValueError(f"State shape mismatch: expected {curr.shape}, got {prev.shape}.")

    prev = np.nan_to_num(prev, nan=0.0, posinf=1.0, neginf=0.0)
    prev = np.clip(prev, 0.0, 1.0)

    a_att = float(np.clip(np.nan_to_num(alpha_attack, nan=1.0), 0.0, 1.0))
    a_rel = float(np.clip(np.nan_to_num(alpha_release, nan=1.0), 0.0, 1.0))

    alphas = np.where(curr > prev, a_att, a_rel)
    smoothed = alphas * curr + (1.0 - alphas) * prev
    smoothed = np.nan_to_num(smoothed, nan=0.0, posinf=1.0, neginf=0.0)
    return np.clip(smoothed, 0.0, 1.0)


def compute_structural_tension(activations, tension_threshold=1e-3):
    """
    Compute deterministic structural tension in [0.0, 1.0] from band activations.

    Returns:
        (tension_scalar, has_tension_bool)
    """
    vec = np.asarray(activations, dtype=np.float64).ravel()
    if vec.size == 0 or not np.all(np.isfinite(vec)):
        return 0.0, False

    vec = np.clip(vec, 0.0, 1.0)
    # Weight upper-structure bands more heavily to measure harmonic/spectral tension
    weights = np.linspace(0.5, 1.0, vec.size, dtype=np.float64)
    tension = float(np.sqrt(np.mean(np.square(vec * weights))))
    tension = float(np.clip(np.nan_to_num(tension, nan=0.0), 0.0, 1.0))

    thresh = float(max(0.0, np.nan_to_num(tension_threshold, nan=1e-3)))
    return tension, bool(tension > thresh)


def evaluate_reinstake_guard(
    tension,
    intent,
    burnout=False,
    pipeline_logic_failure=False,
    tension_threshold=1e-3,
    intent_threshold=1e-3,
):
    """
    Enforce the pipeline safety rule:
        If not tension, not intent, burnout, or pipeline_logic_failure -> do not reinstake.

    Parameters:
        tension: bool or float activation tension level
        intent: bool or float control intent level
        burnout: bool indicating thermal/sustained saturation burnout
        pipeline_logic_failure: bool indicating upstream/downstream invariant failure
        tension_threshold: minimum float threshold when tension is numeric
        intent_threshold: minimum float threshold when intent is numeric

    Returns:
        dict with keys:
            allow_reinstake (bool)
            tension_ok (bool)
            intent_ok (bool)
            burnout (bool)
            pipeline_logic_failure (bool)
            reason (str)
    """
    logic_fail = bool(pipeline_logic_failure)

    # Validate tension
    if isinstance(tension, (bool, np.bool_)):
        tension_ok = bool(tension)
    elif tension is None or not np.isfinite(float(tension)):
        tension_ok = False
        logic_fail = True
    else:
        tension_ok = float(tension) > float(max(0.0, tension_threshold))

    # Validate intent
    if isinstance(intent, (bool, np.bool_)):
        intent_ok = bool(intent)
    elif intent is None or not np.isfinite(float(intent)):
        intent_ok = False
        logic_fail = True
    else:
        intent_ok = float(intent) > float(max(0.0, intent_threshold))

    # Absence of tension or intent under active evaluation flags burnout / logic failure lock
    burnout_flag = bool(burnout) or (not tension_ok and intent_ok)
    if not tension_ok or not intent_ok:
        logic_fail = True

    allow_reinstake = (
        tension_ok and intent_ok and (not burnout_flag) and (not logic_fail)
    )

    if not tension_ok:
        reason = "missing_tension_do_not_reinstake"
    elif not intent_ok:
        reason = "missing_intent_do_not_reinstake"
    elif burnout_flag:
        reason = "burnout_do_not_reinstake"
    elif logic_fail:
        reason = "pipeline_logic_failure_do_not_reinstake"
    else:
        reason = "ok"

    return {
        "allow_reinstake": bool(allow_reinstake),
        "tension_ok": bool(tension_ok),
        "intent_ok": bool(intent_ok),
        "burnout": bool(burnout_flag),
        "pipeline_logic_failure": bool(logic_fail),
        "reason": reason,
    }


class StructuralSmoother:
    """
    Stateful streaming/batch wrapper over spectrum_to_structure with attack/release ballistics
    and a strict tension/intent/burnout/logic-failure reinstake interlock.
    """

    def __init__(
        self,
        sample_rate,
        fft_size,
        hop_size,
        attack_ms=10.0,
        release_ms=150.0,
        bands_hz=DEFAULT_BANDS_HZ,
        enforce_pot_fft=True,
        pot_threshold=1e-6,
        pot_taper_gamma=1.0,
        renormalize_output=False,
        tension_threshold=1e-3,
        burnout_ceiling=0.95,
        burnout_max_frames=64,
        ins_tru=False,
    ):
        self.sample_rate = sample_rate
        self.fft_size = (
            correct_pot_fft_size(fft_size) if enforce_pot_fft else int(fft_size)
        )
        self.hop_size = hop_size
        self.ins_tru = bool(ins_tru)
        self.bands_hz = (
            INSTRUMENT_BANDS_HZ
            if (self.ins_tru and bands_hz is DEFAULT_BANDS_HZ)
            else bands_hz
        )
        self.enforce_pot_fft = enforce_pot_fft
        self.pot_threshold = pot_threshold
        self.pot_taper_gamma = pot_taper_gamma
        self.renormalize_output = renormalize_output

        self.tension_threshold = float(max(0.0, tension_threshold))
        self.burnout_ceiling = float(np.clip(burnout_ceiling, 0.0, 1.0))
        self.burnout_max_frames = int(max(1, burnout_max_frames))

        self.alpha_attack = time_constant_to_alpha(attack_ms, sample_rate, hop_size)
        self.alpha_release = time_constant_to_alpha(release_ms, sample_rate, hop_size)
        self._state = None
        self._burnout_counter = 0
        self.burnout = False
        self.pipeline_logic_failure = False
        self.last_guard_status = evaluate_reinstake_guard(
            tension=True,
            intent=True,
            burnout=False,
            pipeline_logic_failure=False,
        )

    def reset(self, initial_value=None):
        """Hard reset of internal smoother state and fault latches."""
        self._burnout_counter = 0
        self.burnout = False
        self.pipeline_logic_failure = False
        if initial_value is None:
            self._state = None
        else:
            val = float(np.clip(np.nan_to_num(initial_value, nan=0.0), 0.0, 1.0))
            self._state = np.full(len(self.bands_hz), val, dtype=np.float64)

    def reinstake(self, initial_value=None, tension=None, intent=True):
        """
        Guarded state reinstake:
        If not tension, not intent, burnout, or pipeline_logic_failure -> do not reinstake.
        Returns True only if reinstake was permitted and executed.
        """
        if tension is None:
            if self._state is not None:
                tension_val, _ = compute_structural_tension(
                    self._state, self.tension_threshold
                )
            else:
                tension_val = 0.0
        else:
            tension_val = tension

        guard = evaluate_reinstake_guard(
            tension=tension_val,
            intent=intent,
            burnout=self.burnout,
            pipeline_logic_failure=self.pipeline_logic_failure,
            tension_threshold=self.tension_threshold,
        )
        self.last_guard_status = guard

        if not guard["allow_reinstake"]:
            self.burnout = guard["burnout"]
            self.pipeline_logic_failure = guard["pipeline_logic_failure"]
            return False

        if initial_value is None:
            self._state = None
        else:
            val = float(np.clip(np.nan_to_num(initial_value, nan=0.0), 0.0, 1.0))
            self._state = np.full(len(self.bands_hz), val, dtype=np.float64)
        return True

    def process_frame(self, spectrum, intent=True):
        """
        Process a single FFT magnitude frame with tension/intent/burnout protection.
        If the guard trips, the pipeline refuses to reinstake new excitation and
        safely decays existing energy via the release coefficient.
        """
        spec_arr = np.asarray(spectrum, dtype=np.float64).ravel()
        if spec_arr.size == 0 or not np.all(np.isfinite(spec_arr)):
            self.pipeline_logic_failure = True

        raw_vec = spectrum_to_structure(
            spectrum,
            sample_rate=self.sample_rate,
            fft_size=self.fft_size,
            bands_hz=self.bands_hz,
            enforce_pot_fft=self.enforce_pot_fft,
            pot_threshold=self.pot_threshold,
            pot_taper_gamma=self.pot_taper_gamma,
        )

        tension_val, _ = compute_structural_tension(raw_vec, self.tension_threshold)

        # Track sustained saturation burnout
        if float(np.mean(raw_vec)) >= self.burnout_ceiling:
            self._burnout_counter += 1
            if self._burnout_counter >= self.burnout_max_frames:
                self.burnout = True
        else:
            self._burnout_counter = max(0, self._burnout_counter - 1)

        guard = evaluate_reinstake_guard(
            tension=tension_val,
            intent=intent,
            burnout=self.burnout,
            pipeline_logic_failure=self.pipeline_logic_failure,
            tension_threshold=self.tension_threshold,
        )
        self.last_guard_status = guard

        if not guard["allow_reinstake"]:
            # Do not reinstake: block new attack energy and decay safely toward 0.0
            self.burnout = guard["burnout"]
            self.pipeline_logic_failure = guard["pipeline_logic_failure"]
            zero_drive = np.zeros(len(self.bands_hz), dtype=np.float64)
            if self._state is None:
                self._state = zero_drive
            else:
                self._state = smooth_structure_step(
                    zero_drive,
                    self._state,
                    self.alpha_attack,
                    self.alpha_release,
                )
            return self._state.copy()

        self._state = smooth_structure_step(
            raw_vec,
            self._state,
            self.alpha_attack,
            self.alpha_release,
        )

        if self.renormalize_output:
            peak = float(np.max(self._state)) if self._state.size > 0 else 0.0
            denom = max(peak, float(max(0.0, self.pot_threshold)))
            if denom > 0.0 and np.isfinite(denom):
                return np.clip(self._state / denom, 0.0, 1.0)

        return self._state.copy()

    def process_spectrogram(self, spectrogram, intent=True):
        """
        Process a 2D sequence of spectra of shape (num_frames, num_bins)
        and return a 2D activation matrix of shape (num_frames, num_bands).
        """
        spec_2d = np.asarray(spectrogram, dtype=np.float64)
        if spec_2d.ndim != 2:
            raise ValueError("spectrogram must have shape (num_frames, num_bins).")

        num_frames = spec_2d.shape[0]
        out = np.zeros((num_frames, len(self.bands_hz)), dtype=np.float64)
        for t in range(num_frames):
            out[t] = self.process_frame(spec_2d[t], intent=intent)
        return out


def get_pipeline_instructions():
    """
    Return quick-reference instructions for operating the Structural Spectrum Processor.
    """
    return (
        "=== Structural Spectrum Processor Instructions ===\n"
        "1. Single Frame: vec = spectrum_to_structure(spectrum, sample_rate=48000, fft_size=2048)\n"
        "2. Instrument Mode: set ins_tru=True to switch to harmonic instrument bands (INSTRUMENT_BANDS_HZ).\n"
        "3. Streaming Smoother: smoother = StructuralSmoother(48000, 2048, 512, ins_tru=True)\n"
        "4. Reinstake Interlock: smoother.reinstake(tension=..., intent=True) refuses to relatch\n"
        "   if tension/intent are absent or burnout/pipeline_logic_failure is latched.\n"
        "5. Recovery: call smoother.reset() to clear latched burnout or logic faults."
    )


if __name__ == "__main__":
    print(get_pipeline_instructions())
    sr, n_fft, hop = 48000, 2048, 512
    bins = (n_fft // 2) + 1
    synth_spectrum = np.linspace(0.0, 1.0, bins)

    vec_default = spectrum_to_structure(synth_spectrum, sr, n_fft)
    vec_instru = spectrum_to_structure(synth_spectrum, sr, n_fft, ins_tru=True)
    print("Default structure:", np.round(vec_default, 3))
    print("Ins_tru structure:", np.round(vec_instru, 3))

    smoother = StructuralSmoother(sr, n_fft, hop, ins_tru=True)
    frame_out = smoother.process_frame(synth_spectrum, intent=True)
    print("Smoothed frame:   ", np.round(frame_out, 3))
    print("Guard status:     ", smoother.last_guard_status)