# Structural Spectrum Processor (`|X|` Interconnect) & GitHub Snack Airgap Out-Connector

This update ports and interconnects the deterministic 7-band **Structural Spectrum Processor** (`spectrum_to_structure`, Power-of-Two FFT correction, asymmetric attack/release ballistics, `ins_tru` harmonic instrument bands, and the `evaluate_reinstake_guard` safety interlock) directly into the **`|X|` (Osa A-X / GLSL / SY4-EEG / ScreenFilterAnt)** pipeline, while out-connecting any external GitHub snack/webhook channels behind a strict zero-egress airgap disconnector and sterile local bundle exporter.

## User Review & Critical Decisions

> [!IMPORTANT]
> All three architectural choices confirmed during Phase 1 are incorporated below:

- **Confirmed Decision 1 — Full `|X|` Tri-Layer Spectrum Interconnect**: The 7 normalized structural activation bands (`[0.0, 1.0]`) are interconnected simultaneously to:
  1. **Osa A-X Matrix (`|X|` Nodes `Osa-A-X-00..09`)**: Drives per-node harmonic activation, structural tension (`compute_structural_tension`), and phase convergence.
  2. **GLSL Shader Pipeline (`HEX_REFLEX`, `FRACTAL`, `VORONOI`)**: Modulates hexagonal lattice scale, reflex light density, magnetic pressure, and Option C asymmetric frequency filtering.
  3. **SY4-EEG & ScreenFilterAnt Frequency Studio**: Couples the 7-band structural spectrum with the 5-band EEG synthesizer and Option C circular overhead anti-noise filter.
- **Confirmed Decision 2 — GitHub Snack Out-Connect (Airgap Disconnect & Sterile Local Export)**: Adds a dedicated **GitHub Snack Out-Connector & Airgap Disconnector** to the Local-Only Interconnect & Codex pipeline (`ONLY_LOCAL_LOGIC=1`, `check:pass:true_only`). It severs outbound GitHub snack/gist/webhook/PAT channels (`0.0 KB/s` external egress) and generates a sterile, credential-free local verification bundle ready for clipboard copy or local Room audit sealing.
- **Confirmed Decision 3 — Live HUD Controls for `ins_tru` & Reinstake Guard**: Provides real-time HUD toggles between `DEFAULT_BANDS_HZ` (`20 Hz – 20 kHz`) and `INSTRUMENT_BANDS_HZ` (`ins_tru`: `65 Hz – 12 kHz` C2–C6 harmonic bands), plus interactive `reinstake(tension, intent)` and `reset()` fault-latch controls enforcing the rule: *If not tension, not intent, burnout, or pipeline_logic_failure -> do not reinstake*.

---

## 1. Overview & Core Concept

- **What It Does**:
  - Executes deterministic **Power-of-Two (POT) FFT alignment** (`correct_pot_fft_size`), Peak-Over-Threshold (`pot_threshold`) stabilized RMS band integration, potentiometer taper (`pot_taper_gamma`), and asymmetric EMA smoothing (`smooth_structure_step` with attack/release time constants `tau_ms`).
  - Computes real-time **Structural Tension** (`compute_structural_tension`) and enforces the **Reinstake Guard Interlock** (`evaluate_reinstake_guard`): whenever `tension` or `intent` drops below threshold, or sustained saturation `burnout` (`>= 0.95` across frames) or `pipeline_logic_failure` latches, the processor refuses to reinstake new excitation and safely decays existing energy toward `0.0` via the release coefficient.
  - Out-connects external **GitHub Snack** endpoints by locking a dedicated airgap breaker (`GITHUB_SNACK_OUTCONNECTED = TRUE`), verifying zero PAT/token/webhook leakage, and exporting a sterile local-only state digest.
- **Target Audience / Persona**: Systems engineers, neuro-acoustic researchers, and security auditors operating the SY4-EEG / AXIOM `|X|` terminal under strict `ONLY_LOCAL_LOGIC=1` and `Metallurgia:THEME(STEEL ALLOY ANTIMAG POSITION)` constraints.
- **Key Value**: Eliminates unfiltered spectral noise across GLSL and image/EEG pipelines while guaranteeing that neither saturation burnout nor outbound GitHub snack telemetry can breach the local enclave.

---

## 2. User Experience & Visual Design

- **Key User Flows**:
  1. **`|X|` Structural Spectrum Interconnect Deck (Biometrics & Tunnel HUD)**:
     - View the live 7-band structural activation bar graph (`[0.0, 1.0]`) alongside the computed **Structural Tension** scalar and **Reinstake Guard** status badge (`ALLOW_REINSTAKE: TRUE` in emerald vs. `missing_tension_do_not_reinstake` / `burnout_do_not_reinstake` in crimson/amber).
     - Toggle live between **Default Structural Bands (`20 Hz – 20 kHz`)** and **Instrument Harmonic Mode (`ins_tru`: `65 Hz – 12 kHz`, C2 Fundamental to Harmonic Brilliance)**.
     - Adjust **POT Taper Gamma (`pot_taper_gamma`)**, **Attack / Release Ballistics (`10 ms / 150 ms`)**, and **Control Intent (`intent`)**, or simulate saturation burnout / missing tension to watch the Reinstake Interlock block new attack energy and smoothly decay the `|X|` lattice until **Reset / Reinstake** is triggered.
  2. **GitHub Snack Out-Connector & Sterile Export (Tunnel & Codex HUD)**:
     - Inspect the **GitHub Snack Airgap Status** (`OUTCONNECTED // 0.0 KB/S EGRESS`), confirming all outbound snack/gist/webhook/PAT sockets are severed and `compile-best-average.sh --audit-leaks` invariants hold.
     - Trigger **Out-Connect GitHub Snack & Seal Sterile Bundle** to sever any simulated external snack hook, compute a fresh SHA-256 sterile bundle digest, copy the sanitized specification to the clipboard, and log the audit record into the local Room database.
- **Visual Identity & Theme**:
  - *Aesthetic Direction*: `Metallurgia:THEME(STEEL ALLOY ANTIMAG POSITION)` industrial cyber-metallurgy with high-contrast telemetry readouts, brushed steel-slate surfaces, and anti-magnetic cobalt/emerald indicators.
  - *Color Palette & Mood*: Obsidian alloy background (`#080C14`), brushed gunmetal card surfaces (`#101722`), anti-magnetic cobalt cyan (`#38BDF8`) for active `|X|` spectrum interconnects, neon emerald (`#00E676`) for `allow_reinstake == true` and `check:pass:true_only`, amber (`#FFB300`) for `ins_tru` harmonic emphasis, and crimson pink (`#FF4081`) for latched burnout or guard lockouts.
  - *Typography & Hierarchy*: Monospace tabular numerals for Hz band boundaries, POT FFT bin counts (`2048` / `1025` bins), tension scalars, and 64-hex SHA-256 digests; bold geometric headers for `|X|` axis cards.
  - *Component Styling & Layout*: Dense, scannable M3 `HudCard` containers with `8.dp` grid spacing, `48.dp` minimum touch targets on all mode toggles and fault/reset buttons, and custom `Canvas` 7-band spectrum + tension threshold overlays.
- **Interactive Feedback & Motion**:
  - Real-time `Canvas` bar & envelope rendering driven by the asymmetric attack/release ballistics (`alpha_attack` vs. `alpha_release`).
  - Immediate badge transitions and toast confirmations when toggling `ins_tru`, tripping/resetting the Reinstake Guard, or out-connecting the GitHub snack.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Native Kotlin Deterministic Port of `StructuralSmoother` + Embedded Python Reference**:
  - *Chosen Approach*: Implement a 1:1 deterministic Kotlin engine (`StructuralSpectrumProcessorEngine`) matching every mathematical invariant of the attached Python script (`correct_pot_fft_size`, `spectrum_to_structure`, `time_constant_to_alpha`, `smooth_structure_step`, `compute_structural_tension`, `evaluate_reinstake_guard`, and `StructuralSmoother`), while also registering the verbatim Python specification in the Codex & SHA-256 verifier catalog.
  - *Why*: Enables zero-latency 60 FPS execution on Android JVM/Compose without external Python runtime overhead, while preserving byte-for-byte parity with the reference algorithm.
  - *Alternatives Considered*: Running Python via an external bridge, which would add binary bloat and latency incompatible with the 97.6 FPS / 4 192 PTS benchmark target.
- **Decision 2 — Airgap Out-Connection vs. Cloud Webhook Sync for GitHub Snack**:
  - *Chosen Approach*: Enforce a strict outbound disconnector (`GitHubSnackOutconnectState`) integrated with `LocalOnlyPathsInterconnectEngine` (`ONLY_LOCAL_LOGIC=1`) that actively blocks remote `https://gist.github.com` / `api.github.com` snack endpoints and produces a sterile, zero-secret local artifact.
  - *Why*: Aligns with the user's request to "outconnect my github snack" and the repository's Zero-Leak certification.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### Architecture & Component Diagram

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                 STRUCTURAL SPECTRUM PROCESSOR (Kotlin Port)                  │
│  • correctPotFftSize(fftSize, spectrumLen, mode) -> POT N (e.g. 2048)        │
│  • spectrumToStructure(spectrum, sr=48000, fft=2048, insTru, potGamma)       │
│  • computeStructuralTension(activations) -> (tensionScalar, hasTension)      │
│  • evaluateReinstakeGuard(tension, intent, burnout, logicFail)               │
│  • StructuralSmoother (attackMs=10, releaseMs=150, burnoutCeiling=0.95)      │
└──────────────────────┬───────────────────────────┬───────────────────────────┘
                       │                           │
         7-Band Vector + Tension             Guard Status & SHA-256
                       ▼                           ▼
┌─────────────────────────────────────┐ ┌──────────────────────────────────────┐
│      |X| PIPELINE INTERCONNECT      │ │    GITHUB SNACK OUT-CONNECTOR        │
│  1. Osa A-X Matrix (Osa-A-X-00..09) │ │  • Severs external snack/gist egress │
│  2. GLSL Uniforms (Hex/Reflex/Mag)  │ │  • Enforces ONLY_LOCAL_LOGIC = 1     │
│  3. EEG 5-Band & Option C Filter    │ │  • Exports sterile SHA-256 bundle    │
└──────────────────────┬──────────────┘ └──────────────────┬───────────────────┘
                       │                                   │
                       └─────────────────┬─────────────────┘
                                         ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│                     AXIOM VIEWMODEL & JETPACK COMPOSE HUD                    │
│  • BiometricsHudDeck & TunnelHudDeck: Live 7-Band |X| Spectrum & Guard Card  │
│  • LocalOnlyPathsInterconnectCard: GitHub Snack Out-Connect & Airgap Switch  │
│  • CodexAndSpectDecks: Verbatim Python Spec + Room SQLite Audit Persistence  │
└──────────────────────────────────────────────────────────────────────────────┘
```

### Data Model & State

- **`StructuralBandSpec`**: Holds `(lowHz: Double, highHz: Double, label: String, osaNodeCode: String)` for both `DEFAULT_BANDS_HZ` (7 bands: Sub-Bass `20–60 Hz` through Brilliance `8000–20000 Hz`) and `INSTRUMENT_BANDS_HZ` (`ins_tru` 7 bands: Low Fundamental `65–130 Hz` through Harmonic Brilliance `4160–12000 Hz`).
- **`ReinstakeGuardStatus`**: Mirrors the Python dictionary (`allowReinstake: Boolean`, `tensionOk: Boolean`, `intentOk: Boolean`, `burnout: Boolean`, `pipelineLogicFailure: Boolean`, `reason: String`).
- **`StructuralSpectrumUiState`**: Tracks `insTruMode: Boolean`, `sampleRateHz: Int = 48000`, `fftSize: Int = 2048`, `hopSize: Int = 512`, `attackMs: Float = 10f`, `releaseMs: Float = 150f`, `potTaperGamma: Float = 1.0f`, `intentActive: Boolean = true`, `bandActivations: List<Float>` (size 7), `structuralTension: Float`, `burnoutCounter: Int`, `guardStatus: ReinstakeGuardStatus`, and `interconnectXStrength: Float`.
- **`GitHubSnackOutconnectState`**: Tracks `outconnected: Boolean = true`, `airgapLocked: Boolean = true`, `severedEndpointCount: Int = 4`, `lastSterileExportSha256: String`, and `sterileSnackPayload: String`.

### Interactive Component & State Mapping

- **Toggling `ins_tru` (`DEFAULT_BANDS_HZ` ↔ `INSTRUMENT_BANDS_HZ`)**: Reconfigures the `StructuralSmoother` band table, recalculates the 7 normalized band activations, updates the `|X|` Osa A-X node weights, and shifts the Option C frequency filter harmonic center.
- **Tripping / Testing Reinstake Guard (`Intent Toggle`, `Simulate Burnout`, `Reinstake`, `Hard Reset`)**:
  - Turning off `intent` or injecting sustained saturation (`burnout`) transitions `guardStatus.allowReinstake` to `false` with exact reason codes (`missing_intent_do_not_reinstake`, `burnout_do_not_reinstake`, `missing_tension_do_not_reinstake`, `pipeline_logic_failure_do_not_reinstake`).
  - While tripped, `processFrame` feeds `zero_drive` into `smoothStructureStep`, visibly decaying the 7-band `|X|` bars and damping GLSL perturbation until the user taps **Hard Reset (`smoother.reset()`)** and **Guarded Reinstake (`smoother.reinstake()`)**.
- **Out-Connecting GitHub Snack**:
  - Tapping **Out-Connect GitHub Snack** verifies that all remote snack/webhook endpoints are severed (`isStrictlyLocal == true`), updates `check:pass:true_only`, persists a verification entry to Room, and copies the sterile local digest if requested.
